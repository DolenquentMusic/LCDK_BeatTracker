float beatActivationFunct(float *t0, float *tm1, float *tm2){
	return t0[0] + tm1[1] + tm2[2];
}
