void zeroVectorFloat(int len, float *vec) {
	int ii;
	for(ii = 0; ii < len; ii++) {
		vec[ii] = 0.0;
	}
	return;
}

void zeroVectorShort(int len, short *vec) {
	int ii;
	for(ii = 0; ii < len; ii++) {
		vec[ii] = 0;
	}
	return;
}


void zeroVectorInt(int len, int *vec) {
	int ii;
	for(ii = 0; ii < len; ii++) {
		vec[ii] = 0;
	}
	return;
}


void zeroVectorDouble(int len, double *vec) {
	int ii;
	for(ii = 0; ii < len; ii++) {
		vec[ii] = 0;
	}
	return;
}
